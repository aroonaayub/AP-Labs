import java.util.Scanner;
import java.lang.*;

public class Strassen2 {
	//finding n by taking log
	public static int findN(int order){
		int a = (int) (Math.log(order)+ 1);
		System.out.println(a);
		int n = (int) Math.pow(a, 2);
		return n;
	}
	
	
	public static void main(String[] arg){
		Scanner sc = new Scanner(System.in);
		System.out.println(" ");
		
		//taking number of rows and columns of matrix from user
		System.out.println("Enter rows in Matrix A: ");
		int rowsInA = sc.nextInt();
		System.out.println("Enter columns in Matrix A: ");
		int colsInA = sc.nextInt();
		System.out.println("No. of columns in Matrix A = No. of rows in Matrix B.\n");
		System.out.println("Enter columns in Matrix B: ");
		int colsInB = sc.nextInt();
		
		int orderi, orderf = 0;
		
		//checking the largest of which order matrix is to be made
		if(rowsInA >= colsInA){
			orderi = rowsInA;
		}
		else 
			orderi = colsInA;
		
		if(orderi >= colsInB){
			orderf = orderi;
		}
		else 
			orderf = colsInB;
		
		//applying function on n
		int n = findN(orderf);
		
		int[][] a = new int[n][n];
		int[][] b = new int[n][n];
		
		//padding matrix a with 0
		for(int i = 0; i < n ; i++){
			for(int j = 0; j < n; j++){
				a[i][j] = 0;
			}
		}
		
		//padding matrix b with 0
		for(int i = 0; i < n ; i++){
			for(int j = 0; j < n; j++){
				b[i][j] = 0;
			}
		}
		
		//taking matrix a`s entries from user
		System.out.println("Enter 1st Matrix: ");
		for(int i = 0; i < rowsInA ; i++){
			for(int j = 0; j < colsInA; j++){
				a[i][j] = sc.nextInt();
			}
		}

		//taking matrix b`s entries from user
		System.out.println("Enter 2nd Matrix: \n");
		for(int i = 0; i < colsInA ; i++){
			for(int j = 0; j < colsInB; j++){
				b[i][j] = sc.nextInt();
			}
		}
		

		//printing matrix a`s entries padded with 0 from user
		System.out.println("1st Matrix: \n");
		for(int i = 0; i < n ; i++){
			for(int j = 0; j < n; j++){
				System.out.println(a[i][j]+ " ");
			}
			System.out.println();
		}

		//printing matrix a`s entries padded with 0 from user
		System.out.println("2nd Matrix: \n");
		for(int i = 0; i < n ; i++){
			for(int j = 0; j < n; j++){
				System.out.println(b[i][j]+ " ");
			}
			System.out.println();
		}
		
		//making instance of Strassen class for furthur implementation of M and C ki values
		Strassen s = new Strassen();
		
		//calling strassen function to multiply the two
		int[][]C = s.multiply(a, b);
		
		//printing th final result
		System.out.println("\nProduct of matrices A and  B : ");
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
                System.out.print(C[i][j] +" ");
            System.out.println();
        }
 

	}
	
}

