package lab4;

import java.io.BufferedReader;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;


public class fileRead {
	
	public static boolean SetRecord(List<fileData> Data) {

        String csvFile = "read.csv";
        BufferedReader br = null;
        String line = "";
        String cvsSplitBy = ",";
        HashSet<String> lines = new HashSet<>();
        HashSet<String> lines1 = new HashSet<>();
        
        
        Queue q = new PriorityQueue();
        
        try {
            br = new BufferedReader(new FileReader(csvFile));
        } catch (FileNotFoundException ex) {
            Logger.getLogger(fileRead.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        int count = 0;

        try {
            while ((line = br.readLine()) != null && count < 400000) {
                count++;
                if (count < 3) {
                    continue;
                }
                String[] cols = line.split(",");
                String StartDate = cols[0].replace("\"", "");
                String EndDate = cols[1].replace("\"", "");
                String Activity = cols[2].replace("\"", "");
                //String[] col2 = Activity.split("\\(");
                
                if(lines.add(Activity)){
                Data.add(new fileData(StartDate, EndDate, Activity));
                System.out.println(Activity);
                	q.add(Activity);
                }
                else
                {
                	lines1.add(Activity);
                }


            }

            System.out.println("Queue");
            System.out.println(q);
        } 
        catch (IOException ex) {
            Logger.getLogger(fileData.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }

        return true;
    }

	public static void main(String[] args){

	List<fileData> Data = new ArrayList<fileData>();
	boolean b = SetRecord(Data);

    PriorityQueue<String> pq = new PriorityQueue<String>(10);
    

    System.out.println("Geodata Done");
    


}
}
   