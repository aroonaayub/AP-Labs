
package lab4;

public class fileData {

	   private String StartDate;
	   private String EndDate;
	   private String Activity;

	    public fileData() {
	    }

	    public fileData(String StartDate, String EndDate, String Activity) {
	        this.StartDate = StartDate;
	        this.EndDate = EndDate;
	        this.Activity = Activity;
	    }
	    

	    public String getStartDate() {
	        return StartDate;
	    }
	    public String getEndDate() {
	        return EndDate;
	    }
	    public String getActivity() {
	        return Activity;
	    }


	    public void setStartDate(String StartDate) {
	        this.StartDate = StartDate;
	    }
	    public void setEndDate(String EndDate) {
	        this.EndDate = EndDate;
	    }
	    public void setActivity(String Activity) {
	        this.Activity = Activity;
	    }


}
