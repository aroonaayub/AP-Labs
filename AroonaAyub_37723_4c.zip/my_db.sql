#create schema LabAP;
create table Employee;

create table Employee (emp_UID int primary key,emp_Name varchar(50),email varchar(50),store_ID int,
FOREIGN KEY (store_ID) REFERENCES store(store_UID));

create table store (store_UID int primary key, address varchar(50), cont_num varchar(50),email varchar(50));

create table toy (toy_UID int primary key,toy_name varchar(50),price int, min_age int, max_age int,addedOn datetime);